<?php
    include '_dbconnect.php';

if($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_POST['createCoupon'])) {
        $code = $_POST["code"];
        $type = $_POST["type"];
		$value = $_POST["value"];
		$minvalue = $_POST["minvalue"];
		$exp_on = $_POST["exp_on"];

        $sql = "INSERT INTO `coupon_code` (`coupon_code`, `coupon_type`, `coupon_value`,`cart_min_value`,`expired_on`,`added_on`) VALUES ('$code','$type','$value','$minvalue','$exp_on', current_timestamp())";   
        $result = mysqli_query($conn, $sql);
		if ($result){
            echo "<script>alert('created');
                window.location=document.referrer;
                </script>";
        }
        else {
            echo "<script>alert('failed');
                window.location=document.referrer;
                </script>";
        }
        
    }
    if(isset($_POST['removeCoupon'])) {
        $id = $_POST["id"];
        $sql = "DELETE FROM `coupon_code` WHERE `id`='$id'";   
        $result = mysqli_query($conn, $sql);
        if ($result){
            echo "<script>alert('Removed');
                window.location=document.referrer;
                </script>";
        }
        else {
            echo "<script>alert('failed');
                window.location=document.referrer;
                </script>";
        }
    }
    if(isset($_POST['updateCoupon'])) {
        $id = $_POST["id"];
        $c_code = $_POST["code"];
        $c_type = $_POST["type"];
		$c_value = $_POST["value"];
		$cartMin = $_POST["minvalue"];
		$exp_on = $_POST["exp_on"];

        $sql = "UPDATE `coupon_code` SET `coupon_code`='$c_code', `coupon_type`='$c_type', `coupon_value`='$c_value', `cart_min_value`='$cartMin', `expired_on`='$exp_on' WHERE `id`='$id'";   
        $result = mysqli_query($conn, $sql);
        if ($result){
            echo "<script>alert('update');
                window.location=document.referrer;
                </script>";
        }
        else {
            echo "<script>alert('failed');
                window.location=document.referrer;
                </script>";
        }
	}
}
?>
<!doctype html>
<html lang="en">
<head>
 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">
    <title>Cart</title>
    <link rel = "icon" href ="img/kfavicon.png" type = "image/x-icon">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <style>
	
	body {
    font-family: "open_sansregular" !important;
}
	
    #cont{
        min-height : 626px;
    }
    </style>
</head>
<body>
    <?php include 'includes/_dbconnect.php';?>
    <?php require 'includes/_nav.php' ?>
    <?php 
    if($loggedin){
		
		if (! empty($_GET["action"])) {
        switch ($_GET["action"]) {
			 case "show_discount":
           
                if (! empty($_POST["coupon_code"])) {
					$coupon_code=$_POST["coupon_code"];
                    $sql = "SELECT coupon_value FROM coupon_code WHERE coupon_code=$coupon_code";
                    $priceByCode = mysqli_query($conn, $sql);
                    if (! empty($priceByCode)) {
                        foreach ($priceByCode as $key => $value) {
                            $coupon_value = $priceByCode[$key]["coupon_value"];
                        }
                        if (! empty($coupon_value) && $coupon_value > $_POST["totalPrice"]) {
                            $message = "Invalid Discount Coupon";
                        }
                    } else {
                        $message = "Invalid Discount Coupon";
                    }
                }
            
        break;
        case "empty":
            unset($_SESSION["cart_item"]);
            break;
		}
	 }
 ?>
    
    <div class="container" id="cont">
        <div class="row">
            <!--<div class="alert alert-info mb-0" style="width: -webkit-fill-available;">
              <strong>Info!</strong> online payment are currently disabled so please choose cash on delivery.
            </div>-->
            <div class="col-lg-12 text-center border rounded bg-light my-3">
                <h1>My Cart</h1>
            </div>
            <div class="col-lg-8">
                <div class="card wish-list mb-3">
                    <table class="table text-center">
                        <thead class="thead-light">
                            <tr>
                                <th scope="col">No.</th>
                                <th scope="col">Item Name</th>
                                <th scope="col">Item Price</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Total Price</th>
                                <th scope="col">
                                    <form action="includes/_manageCart.php" method="POST">
                                        <button name="removeAllItem" class="btn btn-sm btn-outline-danger">Remove All</button>
                                        <input type="hidden" name="userId" value="<?php $userId = $_SESSION['userId']; echo $userId ?>">
                                    </form>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $sql = "SELECT * FROM `viewcart` WHERE `userId`= $userId";
                                $result = mysqli_query($conn, $sql);
                                $counter = 0;
                                $totalPrice = 0;
								
                                while($row = mysqli_fetch_assoc($result)){
                                    $productId = $row['productId'];
                                    $Quantity = $row['itemQuantity'];
                                    $mysql = "SELECT * FROM `product` WHERE productId = $productId";
                                    $myresult = mysqli_query($conn, $mysql);
                                    $myrow = mysqli_fetch_assoc($myresult);
                                    $productName = $myrow['productName'];
                                    $productPrice = $myrow['productPrice'];
									$total = $productPrice * $Quantity;
                                    $counter++;
						            $totalPrice = $totalPrice + $total;
								    

                                    echo '<tr>
                                            <td>' . $counter . '</td>
                                            <td>' . $productName . '</td>
                                            <td>' . $productPrice . '</td>
                                            <td>
                                                <form id="frm' . $productId . '">
                                                    <input type="hidden" name="productId" value="' . $productId . '">
                                                    <input type="number" name="quantity" value="' . $Quantity . '" class="text-center" onchange="updateCart(' . $productId . ')" onkeyup="return false" style="width:60px" min=1 oninput="check(this)" onClick="this.select();">
                                                </form>
                                            </td>
                                            <td>' . $total . '</td>
                                            <td>
                                                <form action="includes/_manageCart.php" method="POST">
                                                    <button name="removeItem" class="btn btn-sm btn-outline-danger">Remove</button>
                                                    <input type="hidden" name="itemId" value="'.$productId. '">
                                                </form>
                                            </td>
                                        </tr>';
                                }
                                if($counter==0) {
                                    ?><script> document.getElementById("cont").innerHTML = '<div class="col-md-12 my-5"><div class="card"><div class="card-body cart"><div class="col-sm-12 empty-cart-cls text-center"> <img src="https://i.imgur.com/dCdflKN.png" width="130" height="130" class="img-fluid mb-4 mr-3"><h3><strong>Your Cart is Empty</strong></h3><h4>Add something to make me happy :)</h4> <a href="index.php" class="btn btn-primary cart-btn-transform m-3" data-abc="true">continue shopping</a> </div></div></div></div>';</script> <?php
                                }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card wish-list mb-3">
                    <div class="pt-4 border bg-light rounded p-3">
                        <h5 class="mb-3 text-uppercase font-weight-bold text-center">Order summary</h5>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 pb-0 bg-light">Total Price<span>Rs. <?php echo $totalPrice ?></span></li>
                            <li class="list-group-item d-flex justify-content-between align-items-center px-0 bg-light">Shipping<span>Rs. 0</span></li>
                            <li class="list-group-item d-flex justify-content-between align-items-center border-0 px-0 mb-3 bg-light">
                                <div>
                                    <strong>The total amount of</strong>
                                    <strong><p class="mb-0">(including Tax & Charge)</p></strong>
                                </div>
                                <span><strong> <?php echo $totalPrice ?> AED</strong></span>
                            </li>
                        </ul>
						<?php     
                            if (!empty($coupon_value) && $totalPrice > $coupon_value) {
                            $total_price_after_discount = $totalPrice - $coupon_value;
                        ?>
						<div >
                            Discount:<input type="hidden" name="coupon_value" id="coupon_value" value="<?php echo $coupon_value; ?>">
                            <strong><?php echo $coupon_value ?>AED</strong>
                        </div>
						<div>
                            Total after Discount:<input ><span><strong> <?php echo $total_price_after_discount; ?> AED</strong></span>
                        </div>
						<?php 
                        }
                        ?>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" >
                            <label class="form-check-label" for="flexRadioDefault1">
                                Cash On Delivery 
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="flexRadioDefault1" id="flexRadioDefault1">
                            <label class="form-check-label" for="flexRadioDefault1">
                                Online Payment 
                            </label>
                        </div><br>
                        <button type="button" class="btn btn-primary btn-block" data-toggle="modal" data-target="#checkoutModal">go to checkout</button>
                    </div>
                </div>
				<form id="applyDiscountForm" method="post"
                    action="viewCart-Copy(6).php?action=show_discount"
                    onsubmit="return validate();">
				<div class="mb-3">
				  <div id="discount-grid">
                  <div class="discount-section">
                 <div class="discount-action">
                    <span id="error-msg-span" class="error-message">
                    <?php
                    if (! empty($message)) {
                        echo $message;
                    }
                    ?>
                    </span> <span></span><input type="text" class="coupon-code" id="coupon_code" name="coupon_code" size="20" placeholder="Enter Coupon Code" />
                    <input id="btnDiscountAction" type="submit" value="Apply Discount" class="btnDiscountAction" />    
                </div>
            </div>
        </div>
				</div>
				</form>
                
            </div>
        </div>

    </div>
                           
    <?php 
    }
    else {
        echo '<div class="container" style="min-height : 610px;">
        <div class="alert alert-info my-3">
            <font style="font-size:22px"><center>Before checkout you need to <strong><a class="alert-link" data-toggle="modal" data-target="#loginModal">Login</a></strong></center></font>
        </div></div>';
    }
    ?>
	
	<script>
	function validate() {
    var valid= true;
     if($("#discountCode").val() === "") {
        valid = false;
     }

     if(valid == false) {
         $('#error-msg-span').text("Discount Coupon Required");
     }
     return valid;
    }  
	</script>
    <?php require 'includes/_checkoutModal.php'; ?>
    <?php require 'includes/_footer.php' ?>
    
   
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>         
    <script src="https://unpkg.com/bootstrap-show-password@1.2.1/dist/bootstrap-show-password.min.js"></script>
    <script>
        function check(input) {
            if (input.value <= 0) {
                input.value = 1;
            }
        }
        function updateCart(id) {
            $.ajax({
                url: 'includes/_manageCart.php',
                type: 'POST',
                data:$("#frm"+id).serialize(),
                success:function(res) {
                    location.reload();
                } 
            })
        }
    </script>
</body>
</html>
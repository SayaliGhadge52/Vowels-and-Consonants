<?php

include 'includes/_dbconnect.php';
include 'includes/function.php';

$coupon_code = $_POST['coupon_code'];
$res=mysqli_query($conn,"select * from coupon_code where coupon_code='$coupon_code'");
$row=mysqli_fetch_array($res);
if(mysqli_num_rows($res)>0){
	echo json_encode(array(
	                   "statusCode"=>200,
					   "value"=>$row['value']
	));
} else {
	echo json_encode(array("statusCode"=>201));
}
?>






